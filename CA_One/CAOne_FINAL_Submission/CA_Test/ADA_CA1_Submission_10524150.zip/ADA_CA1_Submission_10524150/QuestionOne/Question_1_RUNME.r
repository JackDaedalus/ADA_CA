## CA One Advanced Data Analytics : Module Code B8IT109
## Student Name : Ciaran Finnegan

## Student Number : 10524150

## May 2020

# Run the Shiny Semantic Dashbaord App to display answers to Question One in ADA CA One

## Set Working Directory Accordingly



# This install.packages line is only included to assist in the first run. If these packages are 
# already installed then it is not required.
# install.packages(c("dplyr", "DT", "ggcorrplot", "ggplot2", "plotly", "reshape2", "semantic.dashboard", "shinythemes"))

# If there are issues runing the Shiny App, navidate to the \CADashboard folder and install packages from there.

# This command will launch the 'app.r' file in the CADashboard sub folder. 
# This is the Shiny R application which displays the solutions to Question 1 in the ADA CA

runApp("CADashboard")

